#!/bin/sh
./t-rex -a ethash -o stratum+tcp://eth-eu1.nanopool.org:9999 -u 0x2549BAe2d4B4CeA8078ae359F274BB8796Cb8EFF.rig0/some@email.org -p x
